# table detection > 2025-05-10 1:11pm
https://universe.roboflow.com/table-kddvb/table-detection-xbxw2

Provided by a Roboflow user
License: CC BY 4.0

